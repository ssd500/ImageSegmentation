#include<stdio.h>
int main()
{
  int a;
  scanf("plg give%d",&a);
  printf("\nvalue of a is %d ",a);
return 0;
}
