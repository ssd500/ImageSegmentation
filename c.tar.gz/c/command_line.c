#include<stdio.h>
#include<stdlib.h>
int main()
{
   /*if(argc<3)
    {
       printf(" Wrong input...sorry");
       exit(0);
    }
  printf("  No of command line argument %d \n arguments are \n%s  %s  %s",argc,argv[0],argv[1],argv[2]);
    int sum=atoi(argv[1])+atoi(argv[2]);
    printf("  %d ",sum);*/
   //printf(" Hello World \n");
   float a=2.0;
   (a>2.0)?printf(" True "):printf(" True "); 
return 0;
}
